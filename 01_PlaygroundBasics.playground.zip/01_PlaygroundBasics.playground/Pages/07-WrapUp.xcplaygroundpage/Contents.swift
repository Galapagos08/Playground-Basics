//: ## Wrap up
//: In this playground you've learned a number of things to get you on the road to programming:
//: - Tour of playgrounds and the results sidebar
//: - Doing mathematical calculations
//: - Using comments
//: - Troubleshooting errors when things go wrong
//:
//: Congratulations!
//:
/*:
 _Copyright (C) 2016 Apple Inc. All Rights Reserved.\
 See 00_LICENSE.txt for this sample’s licensing information_
 */
//:[Previous](@previous)  |  page 7 of 7
